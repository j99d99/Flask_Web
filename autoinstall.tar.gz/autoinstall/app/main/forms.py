from flask.ext.wtf import Form
from wtforms import TextField, BooleanField ,StringField, SubmitField
from wtforms.validators import Required

class LoginForm(Form):
    pass
class ShowForm(Form):
    pass
