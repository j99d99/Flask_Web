Highcharts JS v5.0.6 （2016-12-07）

License: http://www.highcharts.com.cn/license

Changelog: http://www.hcharts.cn/docs/changelog

Demos: http://www.hcharts.cn/demos/highcharts

Docs: http://www.hcharts.cn/docs

API: http://api.hcharts.cn/highcharts

Copyright @ 2016 Highsoft AS (http://highsoft.com)

中国地区由杭州简数科技有限公司提供服务（http://jianshukeji.com）